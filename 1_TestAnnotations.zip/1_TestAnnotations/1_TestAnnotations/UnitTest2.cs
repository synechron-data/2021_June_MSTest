﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace _1_TestAnnotations
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void TestMethod1()
        {
            Debug.WriteLine("Inside TestMethod1 - UnitTest2");
        }

        [TestMethod]
        public void TestMethod2()
        {
            Debug.WriteLine("Inside TestMethod2 - UnitTest2");
        }
    }
}
