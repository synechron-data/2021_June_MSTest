using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;

namespace _1_TestAnnotations
{
    [TestClass]
    public class UnitTest1
    {
        [AssemblyInitialize]
        public static void AssemblyInitialize(TestContext context) {
            Debug.WriteLine("Inside AssemblyInitialize");
        }

        [AssemblyCleanup]
        public static void AssemblyCleanup()
        {
            Debug.WriteLine("Inside AssemblyCleanup");
        }

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            Debug.WriteLine("Inside ClassInitialize");
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            Debug.WriteLine("Inside ClassCleanup");
        }

        [TestInitialize]
        public void TestInitialize()
        {
            Debug.WriteLine("Inside TestInitialize");
        }

        [TestCleanup]
        public void TestCleanup()
        {
            Debug.WriteLine("Inside TestCleanup");
        }

        [TestMethod]
        public void TestMethod1()
        {
            Debug.WriteLine("Inside TestMethod1");
        }

        [TestMethod]
        public void TestMethod2()
        {
            Debug.WriteLine("Inside TestMethod2");
        }
    }
}
