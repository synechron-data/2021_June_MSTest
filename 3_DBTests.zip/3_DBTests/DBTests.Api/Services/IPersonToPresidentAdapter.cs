﻿using DBTests.Api.DataAccess;
using DBTests.Api.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBTests.Api.Services
{
    public interface IPersonToPresidentAdapter
    {
        void Adapt(President fromValue, Person toValue);
        void Adapt(Person fromValue, President toValue);
    }
}
