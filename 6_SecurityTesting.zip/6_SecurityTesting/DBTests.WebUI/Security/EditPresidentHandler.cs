﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DBTests.WebUI.Security
{
    public class EditPresidentHandler : AuthorizationHandler<EditPresidentRequirement>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public EditPresidentHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, EditPresidentRequirement requirement)
        {
            if (_httpContextAccessor.HttpContext.Request.RouteValues.ContainsKey("id") == false)
            {
                context.Fail();
            }
            else
            {
                int id = Convert.ToInt32(_httpContextAccessor.HttpContext.Request.RouteValues["id"]);
                var utility = new SecurityUtility(context.User.Identity, context.User);

                if (utility.IsAuthorized(SecurityConstants.PermissionName_Edit, id) == true)
                {
                    context.Succeed(requirement);
                }
                else
                {
                    context.Fail();
                }
            }

            return Task.CompletedTask;
        }
    }
}
