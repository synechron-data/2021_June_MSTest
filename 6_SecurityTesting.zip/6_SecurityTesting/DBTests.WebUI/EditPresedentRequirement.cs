﻿using Microsoft.AspNetCore.Authorization;

namespace DBTests.WebUI
{
    internal class EditPresedentRequirement : IAuthorizationRequirement
    {
    }
}