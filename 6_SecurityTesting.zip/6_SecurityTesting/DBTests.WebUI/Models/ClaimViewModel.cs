﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DBTests.WebUI.Models
{
    public class ClaimViewModel
    {
        public ClaimViewModel(string id, string username, string permission, string presidentName)
        {
            Id = id;
            Username = username;
            Permission = permission;
            PresidentName = presidentName;
        }

        public string Id { get; set; }
        public string Username { get; set; }
        public string Permission { get; set; }
        public string PresidentName { get; set; }
    }
}
