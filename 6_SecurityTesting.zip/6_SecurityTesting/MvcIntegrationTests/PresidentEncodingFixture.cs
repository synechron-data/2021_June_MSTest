﻿using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace MvcIntegrationTests
{
    [TestClass]
    public class PresidentEncodingFixture
    {
        private WebApplicationFactory<DBTests.WebUI.Startup> _systemUnderTest;

        public WebApplicationFactory<DBTests.WebUI.Startup> SystemUnderTest
        {
            get
            {
                if (_systemUnderTest == null)
                {
                    _systemUnderTest =
                        new WebApplicationFactory<DBTests.WebUI.Startup>();
                }

                return _systemUnderTest;
            }
        }

        [TestCategory("Integration")]
        [TestMethod]
        public async Task GetAllPresidents_DefaultMediaTypeReturnedIsJson()
        {
            // Arrange
            var client = SystemUnderTest.CreateDefaultClient();
            var expectedContentType = "application/json";

            // Act

            var response = await client.GetAsync("api/president");

            // Assert

            Assert.AreEqual<string>(
                expectedContentType,
                response.Content.Headers.ContentType.MediaType,
                "Media type header was wrong."
            );

            var responseBody =
                await response.Content.ReadAsStringAsync();

            Assert.AreNotEqual<string>(String.Empty, responseBody,
                "Response body should not be empty.");
        }

        [Ignore]
        [TestCategory("Integration")]
        [TestMethod]
        public async Task GetAllPresidents_MediaTypeReturnedIsXml()
        {
            // Arrange
            var client = SystemUnderTest.CreateDefaultClient();
            var expectedContentType = "application/xml";

            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue(expectedContentType));

            // Act

            var response = await client.GetAsync("api/president");

            // Assert

            Assert.AreEqual<string>(
                expectedContentType,
                response.Content.Headers.ContentType.MediaType,
                "Media type header was wrong."
            );

            var responseBody =
                await response.Content.ReadAsStringAsync();

            Assert.AreNotEqual<string>(String.Empty, responseBody,
                "Response body should not be empty.");
        }
    }
}
