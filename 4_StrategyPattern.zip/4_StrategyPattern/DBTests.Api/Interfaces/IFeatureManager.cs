﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBTests.Api.Interfaces
{
    public interface IFeatureManager
    {
        bool Search { get; }

        bool SearchByBirthDeathState { get; }

        bool FeatureUsageLogging { get; }

        bool CustomerSatisfaction { get; }
    }
}
