using DBTests.Api.Services;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace MvcIntegrationTests
{
    [TestClass]
    public class PresidentRoutingFixture
    {
        private WebApplicationFactory<DBTests.WebUI.Startup> _systemUnderTest;

        public WebApplicationFactory<DBTests.WebUI.Startup> SystemUnderTest
        {
            get
            {
                if (_systemUnderTest == null)
                {
                    _systemUnderTest =
                        new WebApplicationFactory<DBTests.WebUI.Startup>();
                }

                return _systemUnderTest;
            }
        }

        private async Task PopulateTestData()
        {
            var client = SystemUnderTest.CreateDefaultClient();

            var response = await client.GetAsync("/president/VerifyDatabaseIsPopulated");

            Assert.IsNotNull(response, "Response was null.");

            int statusCodeAsInt = (int)response.StatusCode;

            Assert.IsTrue(statusCodeAsInt < 400, "Got an error response from populating test data.");
        }

        [TestMethod]
        public async Task LoadPresidentByLastNameFirstName()
        {
            var client = SystemUnderTest.CreateDefaultClient();

            await PopulateTestData();

            var response = await client.GetAsync("/president/obama/barack");

            Assert.IsNotNull(response, "Response should not be null.");
            Assert.IsTrue(response.IsSuccessStatusCode, "Should be an HTTP success code.");

            var content = await response.Content.ReadAsStringAsync();

            StringAssert.Contains(content, "Obama", "Missing first name");
            StringAssert.Contains(content, "Barack", "Missing last name");
        }

        [TestMethod]
        public async Task LoadPresidentById_LegacyAspx()
        {
            var client = SystemUnderTest.CreateDefaultClient();

            await PopulateTestData();

            int presidentId =
               GetPresidentIdByName("George", "Washington");

            Assert.AreNotEqual<int>(0, presidentId, "President Id was an unexpected value");

            var response = await client.GetAsync(
                String.Format("/president/{0}.aspx", presidentId));

            Assert.IsNotNull(response, "Response should not be null.");
            Assert.IsTrue(response.IsSuccessStatusCode, "Should be an HTTP success code.");

            var content = await response.Content.ReadAsStringAsync();

            StringAssert.Contains(content, "George", "Missing first name");
            StringAssert.Contains(content, "Washington", "Missing last name");
        }

        private int GetPresidentIdByName(string firstName, string lastName)
        {
            var client = SystemUnderTest.CreateDefaultClient();

            var hostServices = SystemUnderTest.Services;

            var scopeFactory = hostServices.GetService(
                typeof(IServiceScopeFactory)) as IServiceScopeFactory;

            using (IServiceScope scope = scopeFactory.CreateScope())
            {
                var presidentService =
                    scope.ServiceProvider.GetService(
                        typeof(IPresidentService)) as IPresidentService;

                Assert.IsNotNull(
                    presidentService,
                    "President service instance was null or unexpected type.");

                var match = presidentService.Search(
                    firstName, lastName).FirstOrDefault();

                Assert.IsNotNull(match, "Could not load president named {0} {1}.", firstName, lastName);

                return match.Id;
            }
        }
    }
}
