﻿using DBTests.Api.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBTests.UnitTests.Services
{
    public class MockPresidentValidatorStrategy : IValidatorStrategy<President>
    {
        public MockPresidentValidatorStrategy()
        {
            IsValidReturnValue = true;
        }

        public bool IsValidReturnValue { get; set; }

        public bool IsValid(President validateThis)
        {
            return IsValidReturnValue;
        }
    }
}
