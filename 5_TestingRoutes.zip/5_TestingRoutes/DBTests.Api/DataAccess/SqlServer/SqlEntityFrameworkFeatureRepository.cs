﻿using DBTests.DataAccess.SqlServer;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace DBTests.Api.DataAccess.SqlServer
{
    public class SqlEntityFrameworkFeatureRepository :
            SqlEntityFrameworkCrudRepositoryBase<Feature, PresidentsDbContext>, IFeatureRepository
    {
        public SqlEntityFrameworkFeatureRepository(
            PresidentsDbContext context) : base(context)
        {
            context.Database.EnsureCreated();
        }

        protected override DbSet<Feature> EntityDbSet => Context.Features;

        public IList<Feature> GetByUsername(string username)
        {
            return (
                from temp in EntityDbSet
                where (temp.Username == username || temp.Username == String.Empty)
                select temp
                ).ToList();
        }
    }
}
