﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DBTests.WebUI.Controllers
{
    public interface ITestDataUtility
    {
        void CreatePresidentTestData();
        void VerifyDatabaseIsPopulated();
    }
}
